Palindromic est la propriété exclusive de Jules ROY Inc.

Toute modification, redistribution, décompilation de ce logiciel sans l'accord de Jules ROY Inc. est passible de poursuites judiciaires.

Contact: julesroydev@gmail.com